<?php

namespace App\Http\Controllers;

use App\Models\Ads;
use App\Models\Category;
use App\Models\Sliders;
use Illuminate\Http\Request;
use Dingo\Api\Routing\Helpers;
use App\Models\Product;
use App\Models\ProductOffer;
use Carbon\Carbon;



class HomeController extends Controller
{
    use Helpers;

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

    public function index(Request $request)
    {
        $sliders = Sliders::whereStatus(1)->get();
        $topCategories = Category::whereTop(1)->get();
        $specialOffers   = Product::whereIn('id',ProductOffer::where('from','<',Carbon::today()->toDateString())->where('to','>',Carbon::today()->toDateString())->pluck('product_id') )->where('status',1)->with('categories','vendor','offer')->limit(8)->get();
        $newProducts   = Product::whereDate('created_at', '>=', Carbon::now()->subDays(app('settings')->new_arrival_days)->toDateTimeString())->where('status',1)->orderby('id','DESC')->limit(8)->get();
        $ads = Ads::where('is_top',0)->where('status',1)->limit(3)->get();
        return view('welcome')->with(compact('sliders','topCategories' ,'specialOffers' ,'newProducts','ads'));
    }


}
